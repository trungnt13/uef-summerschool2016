# Dimension Reduction
## Principal Component Analysis and t-Distributed Stochastic Neighbor Embedding
### Tutors: [Ivan Kukanov](ivan@kukanov.com), [Trung Ngo Trong](trung@imito.ai)


```python
# making inline plot
%matplotlib inline
from __future__ import print_function, division, absolute_import

# use appropriate matplotlib backend for ipython notebook
import matplotlib
matplotlib.use('Agg')
from IPython.core.pylabtools import figsize
figsize(12, 4)
import matplotlib.pyplot as plt

import cPickle

import numpy as np
from scipy import linalg

from sklearn import (manifold, datasets, decomposition,
                     discriminant_analysis)

try:
    import seaborn
except:
    pass
```

# Helper for plotting and PCA

```python
def plot_embedding(X, y, title=None):
    x_min, x_max = np.min(X, 0), np.max(X, 0)
    # normalize
    X = (X - x_min) / (x_max - x_min)

    ax = plt.gca()

    labels = np.unique(y)
    colors = ['b', 'g', 'r', 'c', 'm', 'y', 'k', 'pink', 'darkcyan', 'darkorange']
    _ = []
    for i, c in zip(labels, colors):
        idx = np.where(y == i, True, False)
        x = X[idx]
        _.append(ax.scatter(x[:, 0], x[:, 1], alpha=0.8, c=c))

    plt.xticks([]), plt.yticks([])
    plt.legend(_,
               [str(i) for i in labels],
               scatterpoints=1,
               loc='upper right',
               ncol=3,
               fontsize=8)
    if title is not None:
        plt.title(title)


def PCA(data, n_components):
    # Get number of samples
    N, n_features = data.shape

    # Substract off the mean of each feature
    X = data - np.mean(data, axis=0)

    # Calculate covariance matrix
    X = 1 / (N - 1) * np.dot(X.T, X)
    X = np.cov(X)

    # Compute the eigenvectors and eigenvalues
    eig_values, eig_vectors = linalg.eig(X)

    # How many % each PC explains the variance of the whole data
    eig_values = eig_values.astype('float64')
    print('Variances %:', eig_values / np.sum(eig_values))
    print('Variances cummulative:', np.cumsum(eig_values) / np.sum(eig_values))

    # Project original dataset
    data_proj = np.dot(data, eig_vectors)
    return data_proj[:, :n_components]
```


# Iris example

### load the data

```python
iris = datasets.load_iris()
```

### Get a subset of data

```python
X = iris.data[:]
y = iris.target[:]
print('X:', X.shape)
print('y:', y.shape)
```

### Run the algorithm
```python

nb_features = X.shape[-1]
nb_classes = len(np.unique(y))

x_pca = PCA(X, n_components=2)

# _VALID_METRICS = ['euclidean', 'l2', 'l1', 'manhattan', 'cityblock',
#                   'braycurtis', 'canberra', 'chebyshev', 'correlation',
#                   'cosine', 'dice', 'hamming', 'jaccard', 'kulsinski',
#                   'mahalanobis', 'matching', 'minkowski', 'rogerstanimoto',
#                   'russellrao', 'seuclidean', 'sokalmichener',
#                   'sokalsneath', 'sqeuclidean', 'yule', "wminkowski"]
tsne = manifold.TSNE(n_components=2, learning_rate=1000.0, n_iter=1000, perplexity=30.0,
                     metric="euclidean", init="pca", method='barnes_hut')

x_tsne = tsne.fit_transform(X)


plt.figure()
plt.subplot(121)
plot_embedding(x_pca, y)
plt.subplot(122)
plot_embedding(x_tsne, y)
plt.show()
```

# MNIST example

### load the data

```python
mnist = datasets.load_digits()
```

### Get a subset of data

```python
X = mnist.data[:]
y = mnist.target[:]
print('X:', X.shape)
print('y:', y.shape)
```

### Run the algorithm
```python

nb_features = X.shape[-1]
nb_classes = len(np.unique(y))

x_pca = PCA(X, n_components=2)

# _VALID_METRICS = ['euclidean', 'l2', 'l1', 'manhattan', 'cityblock',
#                   'braycurtis', 'canberra', 'chebyshev', 'correlation',
#                   'cosine', 'dice', 'hamming', 'jaccard', 'kulsinski',
#                   'mahalanobis', 'matching', 'minkowski', 'rogerstanimoto',
#                   'russellrao', 'seuclidean', 'sokalmichener',
#                   'sokalsneath', 'sqeuclidean', 'yule', "wminkowski"]
tsne = manifold.TSNE(n_components=2, learning_rate=1000.0, n_iter=1000, perplexity=30.0,
                     metric="euclidean", init="pca", method='barnes_hut')

x_tsne = tsne.fit_transform(X)


plt.figure()
plt.subplot(121)
plot_embedding(x_pca, y)
plt.subplot(122)
plot_embedding(x_tsne, y)
plt.show()
```

# AML example

### Loading the data

```python
aml_labels, X, y_int, y_str = cPickle.load(
    open('/home/data/AML.pickle', 'r'))
print('X:', X.shape)
print('y:', y_str.shape)
```

### Get a subset of data

```python
X_ = X[:100]
y_str_ = y_str[:100]
y_int_ = y_int[:100]
```

### Run the algorithm

```python
x_pca = PCA(X_, n_components=2)
tsne = manifold.TSNE(n_components=2, learning_rate=1000.0, n_iter=1000, perplexity=30.0,
                     metric="euclidean", init="pca", method='barnes_hut')
x_tsne = tsne.fit_transform(X_)

plt.figure()
plt.subplot(121)
plot_embedding(x_pca, y_str_)
plt.subplot(122)
plot_embedding(x_tsne, y_str_)
plt.show()
```
